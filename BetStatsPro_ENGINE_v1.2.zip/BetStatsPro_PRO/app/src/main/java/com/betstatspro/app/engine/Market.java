package com.betstatspro.app.engine;

public enum Market { OFFSIDES, SHOTS_ON_TARGET, GOAL_KICKS }
