package com.betstatspro.app.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/** Minimal API-FOOTBALL client. Keep the API key on a backend in production. */
public class ApiFootballClient {
    private static final String BASE = "https://v3.football.api-sports.io";
    private final String apiKey;

    public ApiFootballClient(String apiKey) { this.apiKey = apiKey; }

    public JSONArray getFixtures(String query) throws Exception {
        return get("/fixtures?" + query).optJSONArray("response");
    }

    public JSONArray getFixtureDetails(long fixtureId) throws Exception {
        return get("/fixtures?id=" + fixtureId).optJSONArray("response");
    }

    private JSONObject get(String path) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalStateException("API key não configurada");
        }
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("x-apisports-key", apiKey);
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String body = read(stream);
        if (code < 200 || code >= 300) throw new IllegalStateException("API HTTP " + code + ": " + body);
        return new JSONObject(body);
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader r = new BufferedReader(new InputStreamReader(in));
        StringBuilder b = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) b.append(line);
        r.close();
        return b.toString();
    }

    /** Returns a numeric fixture statistic; null means the provider did not collect it. */
    public static Double statistic(JSONArray fixtureResponse, String teamName, String wantedType) {
        if (fixtureResponse == null || fixtureResponse.length() == 0) return null;
        JSONObject fixture = fixtureResponse.optJSONObject(0);
        JSONArray stats = fixture == null ? null : fixture.optJSONArray("statistics");
        if (stats == null) return null;
        for (int i = 0; i < stats.length(); i++) {
            JSONObject block = stats.optJSONObject(i);
            JSONObject team = block == null ? null : block.optJSONObject("team");
            if (team == null || !teamName.equalsIgnoreCase(team.optString("name"))) continue;
            JSONArray values = block.optJSONArray("statistics");
            if (values == null) continue;
            for (int j = 0; j < values.length(); j++) {
                JSONObject item = values.optJSONObject(j);
                if (item != null && wantedType.equalsIgnoreCase(item.optString("type"))) {
                    Object v = item.opt("value");
                    if (v instanceof Number) return ((Number)v).doubleValue();
                    if (v != null) try { return Double.parseDouble(v.toString().replace("%", "")); } catch (Exception ignored) {}
                }
            }
        }
        return null;
    }
}
