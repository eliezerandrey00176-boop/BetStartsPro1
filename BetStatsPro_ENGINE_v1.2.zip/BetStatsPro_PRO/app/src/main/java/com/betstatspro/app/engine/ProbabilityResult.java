package com.betstatspro.app.engine;

public class ProbabilityResult {
    public final Market market;
    public final double line;
    public final double probabilityOver;
    public final double fairOdds;
    public final String grade;
    public final double expectedMean;
    public final String warning;

    public ProbabilityResult(Market market, double line, double probabilityOver, double fairOdds, String grade, double expectedMean, String warning) {
        this.market = market;
        this.line = line;
        this.probabilityOver = probabilityOver;
        this.fairOdds = fairOdds;
        this.grade = grade;
        this.expectedMean = expectedMean;
        this.warning = warning;
    }
}
