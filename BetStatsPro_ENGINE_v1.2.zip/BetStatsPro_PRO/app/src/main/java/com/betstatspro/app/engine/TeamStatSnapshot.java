package com.betstatspro.app.engine;

public class TeamStatSnapshot {
    public final double avgFor;
    public final double avgAgainst;
    public final double homeAwayFactor;
    public final int sampleSize;
    public final boolean providerCoverage;

    public TeamStatSnapshot(double avgFor, double avgAgainst, double homeAwayFactor, int sampleSize, boolean providerCoverage) {
        this.avgFor = avgFor;
        this.avgAgainst = avgAgainst;
        this.homeAwayFactor = homeAwayFactor;
        this.sampleSize = sampleSize;
        this.providerCoverage = providerCoverage;
    }
}
