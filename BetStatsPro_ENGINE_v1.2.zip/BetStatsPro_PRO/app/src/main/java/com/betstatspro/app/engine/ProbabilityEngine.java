package com.betstatspro.app.engine;

/**
 * First production-oriented scoring engine.
 * It estimates the mean for a match and then uses a Poisson distribution
 * to price integer/half-integer over lines. Calibration should be trained
 * on historical results before public release.
 */
public final class ProbabilityEngine {
    private ProbabilityEngine() {}

    public static ProbabilityResult estimate(Market market, double line, MatchProfile p) {
        if (p == null || p.home == null || p.away == null) {
            throw new IllegalArgumentException("Match profile incompleto");
        }
        double homeMean = blendedMean(p.home, p.away);
        double awayMean = blendedMean(p.away, p.home);
        double mean = Math.max(0.05, homeMean + awayMean);

        // Home/away samples with missing provider coverage reduce confidence.
        int n = p.home.sampleSize + p.away.sampleSize;
        boolean covered = p.home.providerCoverage && p.away.providerCoverage;
        String warning = covered ? "" : "Mercado sem cobertura completa do provedor";

        double probability = poissonOver(mean, line);
        double fairOdds = probability > 0 ? 1.0 / probability : 99.0;
        double reliability = reliabilityScore(n, covered, p.home, p.away);
        String grade = grade(probability, reliability);

        return new ProbabilityResult(market, line, probability, fairOdds, grade, mean, warning);
    }

    private static double blendedMean(TeamStatSnapshot team, TeamStatSnapshot opponent) {
        // 55% team production + 35% opponent allowance + 10% venue factor.
        double base = 0.55 * team.avgFor + 0.35 * opponent.avgAgainst;
        return Math.max(0.0, base * clamp(team.homeAwayFactor, 0.80, 1.20));
    }

    /** P(X > line), with half-lines interpreted naturally as integer thresholds. */
    private static double poissonOver(double lambda, double line) {
        int threshold = (int) Math.floor(line) + 1;
        double cumulative = 0.0;
        double term = Math.exp(-lambda);
        cumulative += term;
        for (int k = 1; k <= threshold - 1; k++) {
            term *= lambda / k;
            cumulative += term;
        }
        return clamp(1.0 - cumulative, 0.0001, 0.9999);
    }

    private static double reliabilityScore(int n, boolean covered, TeamStatSnapshot a, TeamStatSnapshot b) {
        double sample = clamp(n / 20.0, 0.0, 1.0);
        double coverage = covered ? 1.0 : 0.55;
        double disagreement = Math.abs(a.avgFor - b.avgAgainst) / Math.max(1.0, a.avgFor + b.avgAgainst);
        return clamp(0.45 + 0.40 * sample + 0.15 * coverage - 0.15 * disagreement, 0.0, 1.0);
    }

    private static String grade(double probability, double reliability) {
        double score = probability * reliability;
        if (score >= 0.68 && probability >= 0.76) return "FORTE";
        if (score >= 0.57 && probability >= 0.68) return "BOA";
        if (score >= 0.45 && probability >= 0.58) return "MODERADA";
        return "FRACA";
    }

    private static double clamp(double x, double lo, double hi) {
        return Math.max(lo, Math.min(hi, x));
    }
}
