package com.betstatspro.app.engine;

public class MatchProfile {
    public final TeamStatSnapshot home;
    public final TeamStatSnapshot away;

    public MatchProfile(TeamStatSnapshot home, TeamStatSnapshot away) {
        this.home = home;
        this.away = away;
    }
}
