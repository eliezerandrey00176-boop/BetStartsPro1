package com.betstatspro.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list; TextView top; ArrayList<Pick> picks = new ArrayList<>();
    enum Market { OFFSIDES, GOALKICKS, SOT }
    static class Pick { String match, line, market; double p, fairOdd; Market type; Pick(String m,String l,String mk,double p,double o,Market t){match=m;line=l;market=mk;this.p=p;fairOdd=o;type=t;} }

    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); list=findViewById(R.id.list); top=findViewById(R.id.txtTop); seed(); render(null);
        findViewById(R.id.btnAll).setOnClickListener(v->render(null));
        findViewById(R.id.btnOff).setOnClickListener(v->render(Market.OFFSIDES));
        findViewById(R.id.btnGK).setOnClickListener(v->render(Market.GOALKICKS));
        findViewById(R.id.btnSOT).setOnClickListener(v->render(Market.SOT));
    }
    void seed(){
        // Demo data. Production version replaces these with API data and calibrated historical features.
        picks.add(new Pick("Newcastle x Bournemouth","+2,5","Impedimentos",0.79,1.27,Market.OFFSIDES));
        picks.add(new Pick("Lincoln City x Southampton","+8,5","Chutes no alvo",0.76,1.32,Market.SOT));
        picks.add(new Pick("Peterborough x Sheffield Wed.","+8,5","Tiros de meta",0.74,1.35,Market.GOALKICKS));
        picks.add(new Pick("Southend x Yeovil","+2,5","Impedimentos",0.73,1.37,Market.OFFSIDES));
        picks.add(new Pick("Aldershot x Halifax","+8,5","Tiros de meta",0.71,1.41,Market.GOALKICKS));
        picks.add(new Pick("Preston x Blackburn","+7,5","Chutes no alvo",0.69,1.45,Market.SOT));
        picks.add(new Pick("Stoke x Charlton","+2,5","Impedimentos",0.67,1.49,Market.OFFSIDES));
    }
    void render(Market filter){list.removeAllViews(); ArrayList<Pick> shown=new ArrayList<>(); for(Pick p:picks) if(filter==null||p.type==filter) shown.add(p); shown.sort((a,c)->Double.compare(c.p,a.p));
        if(!shown.isEmpty()){Pick x=shown.get(0); top.setText(x.match+"\n"+x.market+" "+x.line+"  •  "+pct(x.p)+" de probabilidade\nOdd justa do modelo: "+String.format(Locale.US,"%.2f",x.fairOdd)+"  •  Confiança "+confidence(x.p));}
        for(Pick p:shown) list.addView(card(p));
    }
    View card(Pick p){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(18,16,18,16);GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(28);box.setBackground(bg);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.setMargins(0,0,0,12);box.setLayoutParams(bp);
        TextView t=tv(p.match,17,Color.rgb(23,32,51),true);box.addView(t);box.addView(tv(p.market+"  •  Linha "+p.line,14,Color.rgb(102,112,133),false));
        TextView prob=tv(pct(p.p)+"  •  "+confidence(p.p),22,p.p>=.72?Color.rgb(0,168,120):Color.rgb(245,158,11),true);prob.setPadding(0,10,0,4);box.addView(prob);
        box.addView(tv("Odd justa: "+String.format(Locale.US,"%.2f",p.fairOdd)+"   |   Valor só existe se a odd oferecida for maior que a odd justa.",12,Color.rgb(102,112,133),false));
        return box; }
    TextView tv(String s,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setTypeface(null,bold?Typeface.BOLD:Typeface.NORMAL);return v;}
    String pct(double p){return Math.round(p*100)+"%";} String confidence(double p){return p>=.75?"MUITO FORTE":p>=.70?"FORTE":p>=.65?"BOA":"MODERADA";}
}
