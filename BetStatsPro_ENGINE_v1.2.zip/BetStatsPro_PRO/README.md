# BetStats Pro — Motor de Análise v1.1

Projeto Android base para um app de análise probabilística de futebol.

## Mercados prioritários
- Impedimentos
- Chutes no alvo
- Tiros de meta

## Arquitetura do motor
1. Coletar jogos históricos e próximos.
2. Normalizar estatísticas por equipe, mando e adversário.
3. Calcular expectativa do mercado para cada lado.
4. Somar expectativas e modelar a distribuição do total.
5. Calcular P(total > linha) e odd justa.
6. Reduzir confiança quando a amostra é pequena ou a cobertura do provedor é incompleta.
7. Registrar previsão e resultado para backtest e calibração.

### Modelo atual
O `ProbabilityEngine` usa uma combinação ponderada de produção da equipe, concessão do adversário e fator casa/fora, seguida de uma distribuição de Poisson para estimar o total acima da linha. Isso é um **baseline**, não uma garantia de acerto. Antes da publicação, deve ser calibrado com dados históricos e validado fora da amostra.

## Fonte de dados
O cliente `ApiFootballClient` está preparado para API-FOOTBALL. A API documenta estatísticas de partidas como chutes no alvo, chutes totais e impedimentos. Nem toda competição fornece todas as estatísticas; o app deve tratar `null` como falta de cobertura. citehttps://www.api-football.com/news/post/how-to-get-started-with-api-football-a-complete-beginners-guide

**Tiros de meta:** não assumir disponibilidade na API principal. O motor deve receber esse mercado por um provedor que realmente o entregue. Se não houver dado, o app deve marcar “sem cobertura”, nunca inventar uma média.

## Segurança da API
Não coloque uma chave de API fixa no APK de produção. O desenho recomendado é:
`Android -> backend BetStats Pro -> provedor de dados`.

O backend também deve fazer cache, agregação e controle de quota. A própria documentação do provedor recomenda evitar chamadas duplicadas e buscar detalhes apenas quando necessários. citehttps://www.api-football.com/news/post/how-to-optimize-api-sports-calls-and-quota-usage

## Próxima etapa técnica
- Backend (API própria)
- Banco histórico
- ETL de partidas
- Backtest por liga/mercado/linha
- Calibração (Brier score + reliability curve)
- Ranking de oportunidades
- Odds e cálculo de valor esperado
- Testes automatizados
- APK/AAB de produção
